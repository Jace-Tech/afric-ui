<!--==================================================-->
	<!-- Start Sidebar Area -->
	<!--==================================================-->
	<div class="sidebar-group info-group">
		<div class="sidebar-widget">
			<div class="sidebar-widget-container">
				<div class="widget-heading">
					<a href="#" class="close-side-widget">
						<i class="bi bi-x-lg"></i>
					</a>
				</div>
				<div class="sidebar-textwidget">
					<div class="sidebar-info-contents">
						<div class="content-inner">
							<div class="sidebar-logo">
								<a href="index"><img src="logo.png" alt="africneibor logo" height="150"></a>
							</div>
							<div class="sidebar-widget-menu">
								<ul>
									<li class="dropdown"><a href="index" data-toggle="dropdown">Home</a>
										
									</li>
									<li class="dropdown"><a href="about" data-toggle="dropdown">About Us</a></li>
									<li class="dropdown"><a href="services" data-toggle="dropdown">Our Services <i
												class="icon-arrow"></i></a>
										<ul class="dropdown-menu">
											<li><a href="services">Tenant Management</a></li>
											<li><a href="services">Lease Management</a></li>
											<li><a href="services">Maintenance Requests</a></li>
											<li><a href="services">Secure Document Storage</a></li>
											<li><a href="services">Facial Recognition for Enhanced Security</a></li>
											<li><a href="services">Background Checks for Peace of Mind</a></li>

											
										</ul>
									</li>
									<li class="dropdown"><a href="contact" data-toggle="dropdown">Contact us</a></li>
									<li class="dropdown"><a href="account/signup-email" data-toggle="dropdown">Register with us</a>
										
									</li>
									<li class="dropdown"><a href="account/login" data-toggle="dropdown">Login</a>
										
									</li>
								</ul>
							</div>
							<div class="contact-info">
								<h2>Contact Info</h2>
								<ul class="list-style-one">
									<li><i class="bi bi-geo-alt-fill"></i>Lagos, Nigeria</li>
									<li><i class="bi bi-telephone-fill"></i>(+001) 123-456-789</li>
									<li><i class="bi bi-envelope"></i> info@africneibor.com</li>
									
								</ul>
							</div>
							<ul class="social-box">
								<li class="facebook"><a href="#" class="fab fa-facebook-f"></a></li>
								<li class="twitter"><a href="#" class="fab fa-instagram"></a></li>
								<li class="linkedin"><a href="#" class="fab fa-twitter"></a></li>
								<li class="instagram"><a href="#" class="fab fa-pinterest-p"></a></li>
								<li class="youtube"><a href="#" class="fab fa-linkedin-in"></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--==================================================-->
	<!-- End Sidebar Area -->
	<!--==================================================-->
	<!--==================================================-->
	<!-- Start Footer Area -->
	<!--==================================================-->
	<div class="footer-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-6">
					<div class="footer-wiget wow fadeInUp" data-wow-delay="0.2s" data-wow-duration="1s">
						<div class="footer-wiget-title">
							<h4>Quick link</h4>
						</div>
						<div class="footer-wiget-menu">
							<ul>
								<li><a href="index">Home</a></li>
								<li><a href="about">About Us</a></li>
								<li><a href="faq">FAQ</a></li>
								<li><a href="services">Our Services</a></li>
								<li><a href="contact">Contact Us</a></li>
								<li><a href="account/signup-email">Register with us</a></li>
								<li><a href="account/login">Login</a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-lg-5 col-md-6">
					<div class="footer-wiget inner2 wow fadeInUp" data-wow-delay="0.4s" data-wow-duration="1s">
						<div class="footer-wiget-title">
							<h4>Our Services</h4>
						</div>
						<div class="footer-wiget-menu">
							<ul>
								<li><a href="services">Tenant Management</a></li>
								<li><a href="services">Lease Management</a></li>
								<li><a href="services">Maintenance Requests</a></li>
								<li><a href="services">Background Checks for Peace of Mind</a></li>
								<li><a href="services">Facial Recognition for Enhanced Security</a></li>
								<li><a href="services">Secure Document Storage</a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="footer-wiget inner">
						<div class="footer-wiget-logo">
							<a href="index"><img src="logo.png" alt="africneibor" width="120" height="100"></a>
						</div>
						<div class="footer-wiget-text">
							<h4>At AfricNeibor, our mission is<br> to empower property owners 
							to take control of their rental properties,<br> enhance tenant satisfaction, and maximize profitability.</h4>
						</div>
						<div class="footer-social">
							<ul>
								<li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
								<li><a href="#"><i class="fab fa-twitter"></i></a></li>
								<li><a href="#"><i class="fab fa-vimeo-v"></i></a></li>
								<li><a href="#"><i class="fab fa-instagram"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
				
			</div>
		</div>
	</div>
	<!--==================================================-->
	<!-- End Footer Area -->
	<!--==================================================-->

	<!--==================================================-->
	<!-- Start Serch Pop Up section Area -->
	<!--==================================================-->
	<!-- serch pop up section -->
	<div class="search-popup">
		<button class="close-search style-two"><span class="flaticon-multiply"><i class="far fa-times-circle"></i></span></button>
		<button class="close-search"><i class="fas fa-arrow-up"></i></button>
		<form method="post" action="#">
			<div class="form-group">
				<input type="search" name="search-field" value="" placeholder="Search Here" required="">
				<button type="submit"><i class="fa fa-search"></i></button>
			</div>
		</form>
	</div>
	<!--==================================================-->
	<!-- End Serch Pop Up  section Area -->
	<!--==================================================-->


	<!--==================================================-->
	<!-- Start scrollup section Area -->
	<!--==================================================-->
	<!-- scrollup section -->
	<div class="prgoress_scrollup">
		<svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
			<path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
		</svg>
	</div>
	<!--==================================================-->
	<!-- End scrollup section Area -->
	<!--==================================================-->


	<!-- jquery js -->
	<script src="assets/js/vendor/jquery-3.6.2.min.js"></script>

	<script src="assets/js/popper.min.js"></script>

	<!-- bootstrap js -->
	<script src="assets/js/bootstrap.min.js"></script>

	<!-- carousel js -->
	<script src="assets/js/owl.carousel.min.js"></script>

	<!-- counterup js -->
	<script src="assets/js/jquery.counterup.min.js"></script>

	<!-- waypoints js -->
	<script src="assets/js/waypoints.min.js"></script>

	<!-- wow js -->
	<script src="assets/js/wow.min.js"></script>

	<!-- imagesloaded js -->
	<script src="assets/js/imagesloaded.pkgd.min.js"></script>

	<!-- venobox js -->
	<script src="venobox/venobox.js"></script>

	<!--  animated-text js -->
	<script src="assets/js/animated-text.js"></script>

	<!-- venobox min js -->
	<script src="venobox/venobox.min.js"></script>

	<!-- isotope js -->
	<script src="assets/js/isotope.pkgd.min.js"></script>

	<!-- jquery meanmenu js -->
	<script src="assets/js/jquery.meanmenu.js"></script>

	<!-- jquery scrollup js -->
	<script src="assets/js/jquery.scrollUp.js"></script>

	<!-- Slick Slider -->
	<script src="assets/slick/slick.min.js"></script>

	<script src="assets/js/jquery.barfiller.js"></script>
	<!-- jquery js -->

	<!-- ragrslider js -->
	<script src="assets/js/rangeslider.js"></script>

	<!-- ragrslider js -->
	<script src="assets/js/mixitup.min.js"></script>

	<!-- theme js -->
	<script src="assets/js/theme.js"></script>

	<!-- scroll js -->
	<script src="assets/js/script.js"></script>

</body>

</html>