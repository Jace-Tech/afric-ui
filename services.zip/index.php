<?php
$title = "AFRICNEIBOR - Your trusted partner in property management";
$desc="Welcome to AfricNeibor, your trusted partner in modernizing property management across Nigeria. AfricNeibor offers innovative solutions tailored to the needs of landlords, property owners, and tenants alike.";
 include("header.php"); ?>

	<!--==================================================-->
	<!-- Start Banner Area -->
	<!--==================================================-->

	<section class="banner-section">
		<div class="banner-carousel owl-carousel">
			<div class="slide-item one">
				<div class="image-layer" style="background-image: url('assets/images/slider/banner2.jpeg');"></div>
				<div class="container">
					<div class="slider-content">
						<div class="slider-sub-title">
							<h4>premier solution for streamlined rental property management</h4>
						</div>
						<div class="slider-main-title">
							<h1>Welcome to AfricNeibor</h1>
						</div>
						<div class="slider-discription">
							<p>Managing rental properties has historically been a complex and challenging task, but with AfricNeibor, 
							we offer a comprehensive suite of services and a user-friendly website to simplify the entire process. </p>
						</div>
						<div class="Lifesafe-btn slider1">
							<a href="about">Discover More</a>
						</div>
						<!-- <div class="video-icon">
							<a class="video-vemo-icon venobox vbox-item" data-vbtype="youtube" data-autoplay="true"
								href="https://youtu.be/BS4TUd7FJSg"><i class="bi bi-play"></i></a>
						</div> -->
					</div>
				</div>
			</div>
			<div class="slide-item two">
				<div class="image-layer" style="background-image: url('assets/images/slider/banner3.jpg');"></div>
				<div class="container">
					<div class="slider-content">
						<div class="slider-sub-title">
							<h4>We offer the best maintenance for your property</h4>
						</div>
						<div class="slider-main-title">
							<h1>Best company for
							 property management</h1>
						</div>
						<div class="slider-discription">
							<p>we specialize in enhancing property maintenance, tenant tracking, and simplifying property ownership for landlords and property owners across Nigeria </p>
						</div>
						<div class="Lifesafe-btn slider1">
							<a href="about">Discover More</a>
						</div>
						
					</div>
				</div>
			</div>
		</div>
	</section>
	<!--==================================================-->
	<!-- End Banner Area -->
	<!--==================================================-->


	<!--==================================================-->
	<!-- Start Feature Area -->
	<!--==================================================-->
	<div class="feature-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-6">
					<div class="feature-single-box wow fadeInUp" data-wow-delay="0.2s" data-wow-duration="1s">
						<div class="fetaure-icon">
							<img src="assets/images/service/feature-icon1.png" alt="">
						</div>
						<div class="feature-content">
							<h4>Trusted Company</h4>
							<p>your trusted partner in modernizing property management across Nigeria</p>
						</div>
						<div class="feature-shape">
							<img src="assets/images/service/feature-one-shape-1.png" alt="">
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-6">
					<div class="feature-single-box wow fadeInUp" data-wow-delay="0.4s" data-wow-duration="1s">
						<div class="fetaure-icon">
							<img src="assets/images/service/feature-icon4.png" alt="africneibor">
						</div>
						<div class="feature-content">
							<h4>Innovative Technology</h4>
							<p>We leverage the latest advancements in technology to manage your properties.</p>
						</div>
						<div class="feature-shape">
							<img src="assets/images/service/feature-one-shape-1.png" alt="africneibor">
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-6">
					<div class="feature-single-box wow fadeInUp" data-wow-delay="0.6s" data-wow-duration="1s">
						<div class="fetaure-icon">
							<img src="assets/images/service/feature-icon3.png" alt="africneibor">
						</div>
						<div class="feature-content">
							<h4>Focus on Security</h4>
							<p>We understand the importance of safeguarding your property and tenant data.</p>
						</div>
						<div class="feature-shape">
							<img src="assets/images/service/feature-one-shape-1.png" alt="africneibor">
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-6">
					<div class="feature-single-box wow fadeInUp" data-wow-delay="0.8s" data-wow-duration="1s">
						<div class="fetaure-icon">
							<img src="assets/images/service/feature-icon4.png" alt="africneibor">
						</div>
						<div class="feature-content">
							<h4>24/7 Fast Support</h4>
							<p>Our dedicated team is committed to providing exceptional customer support every step of the way.</p>
						</div>
						<div class="feature-shape">
							<img src="assets/images/service/feature-one-shape-1.png" alt="">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--==================================================-->
	<!-- End Feature Area -->
	<!--==================================================-->

	<!--==================================================-->
	<!-- Start About Area -->
	<!--==================================================-->
	<div class="about-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-5 col-md-12">
					<div class="about-thumb wow fadeInRight" data-wow-delay="0.3s" data-wow-duration="1s">
						<img src="assets/images/about/im1.jpg" alt="africneibor">
					</div>
				</div>
				<div class="col-lg-7 col-md-12">
					<div class="section-title wow fadeInUp" data-wow-delay="0.2s" data-wow-duration="1s">
						<div class="section-sub-title">
							<h4>About Our Company</h4>
						</div>
						<div class="section-main-title about">
							<h2>Your Trusted Partner in Property Management</h2>
						</div>
					</div>
					<div class="about-discription wow fadeInUp" data-wow-delay="0.4s" data-wow-duration="1s">
						<p>Your trusted partner in modernizing property management across Nigeria. Founded with a vision to simplify the complexities of managing rental properties, AfricNeibor offers innovative solutions tailored to the needs of landlords, property owners, and tenants alike. </p>
					</div>
					<div class="row">
						<div class="col-lg-12">
							<div class="tab list-tab">
								<ul class="tabs active wow fadeInUp" data-wow-delay="0.2s" data-wow-duration="1s">
									<li class="current"><a href="#">Our Mission</a></li>
									<li><a href="#">Our Vision</a></li>
									<li><a href="#">Why choose us</a></li>
								</ul>
								<div class="tab_content">
									<div class="tabs_item">
										<div class="row">
											<div class="col-lg-4 col-md-12 col-sm-6">
												<div class="about-thumb wow fadeInRight" data-wow-delay="0.2s"
													data-wow-duration="1s">
													<img src="assets/images/about/im2.jpg" alt="africneibor">
												</div>
											</div>
											<div class="col-lg-8 col-md-12 col-sm-6">
												<div class="about-list wow fadeInUp" data-wow-delay="0.4s"
													data-wow-duration="1s">
													<ul>
														<li><i class="bi bi-chevron-double-right"></i> Empower property owners to take control of their rental properties</li>
														<li><i class="bi bi-chevron-double-right"></i> enhance tenant satisfaction
														</li>
														<li><i class="bi bi-chevron-double-right"></i> maximize profitability through cutting-edge technology and unparalleled service
														</li>
													</ul>
												</div>
											</div>
										</div>
									</div>
									<div class="tabs_item" style="display: none;">
										<div class="row">
											<div class="col-lg-4 col-md-12 col-sm-6">
												<div class="about-thumb wow fadeInRight" data-wow-delay="0.2s"
													data-wow-duration="1s">
													<img src="assets/images/about/im4.jpg" alt="africneibor">
												</div>
											</div>
											<div class="col-lg-8 col-md-12 col-sm-6">
												<div class="about-list wow fadeInUp" data-wow-delay="0.4s"
													data-wow-duration="1s">
													<ul>
														<li><i class="bi bi-chevron-double-right"></i> To simplify the complexities of managing rental properties </li>
														<li><i class="bi bi-chevron-double-right"></i> To offer innovative solutions tailored to the needs of landlords, property owners, and tenants alike.
														</li>
														<li><i class="bi bi-chevron-double-right"></i> To be the best property management company
														</li>
													</ul>
												</div>
											</div>
											
										</div>
									</div>
									<div class="tabs_item" style="display: none;">
										<div class="row">
											<div class="col-lg-4 col-md-12 col-sm-6">
												<div class="about-thumb wow fadeInRight" data-wow-delay="0.2s"
													data-wow-duration="1s">
													<img src="assets/images/about/im3.jpg" alt="africneibor">
												</div>
											</div>
											<div class="col-lg-8 col-md-12 col-sm-6">
												<div class="about-list wow fadeInUp" data-wow-delay="0.4s"
													data-wow-duration="1s">
													<ul>
														<li><i class="bi bi-chevron-double-right"></i> We understand the importance of safeguarding your property </li>
														<li><i class="bi bi-chevron-double-right"></i> We provide exceptional customer service
														</li>
														<li><i class="bi bi-chevron-double-right"></i> We leverage technology to manage your properties
														</li>
													</ul>
												</div>
											</div>
											
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--==================================================-->
	<!-- End About Area -->
	<!--==================================================-->


	<!--==================================================-->
	<!-- Start Service Area -->
	<!--==================================================-->
	<div class="service-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="section-title text-center wow fadeInUp" data-wow-delay="0.2s" data-wow-duration="1s">
						<div class="section-sub-title">
							<h4>Our Services</h4>
						</div>
						
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-4 col-md-6 mt-5">
					<div class="service-single-box wow fadeInUp" data-wow-delay="0.4s" data-wow-duration="1s">
						<div class="service-thumb">
							<img src="assets/images/slider/im.png" height="250" alt="africneibor">
							<div class="service-icon">
								<img src="assets/images/service/service-icon1.png" alt="africneibor">
							</div>
						</div>
						<div class="service-content">
							<h4><a href="services"> Tenant Management</a></h4>
							<p>Provide thorough background checks on all tenants, hotels, and restaurant customers, ensuring a safe and secure environment.</p>
						</div>
						<div class="Lifesafe-btn service">
							<a href="services">Read More +</a>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 mt-5">
					<div class="service-single-box wow fadeInUp" data-wow-delay="0.6s" data-wow-duration="1s">
						<div class="service-thumb">
							<img src="assets/images/about/im2.jpg" height="250" alt="africneibor">
							<div class="service-icon">
								<img src="assets/images/service/service-icon2.png" alt="africneibor">
							</div>
						</div>
						<div class="service-content">
							<h4><a href="services"> Lease Management</a></h4>
							<p>Keep track of lease agreements, renewals, and rent payments effortlessly, ensuring timely payments and compliance</p>
						</div>
						<div class="Lifesafe-btn service">
							<a href="#">Read More +</a>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 mt-5">
					<div class="service-single-box wow fadeInUp" data-wow-delay="0.8s" data-wow-duration="1s">
						<div class="service-thumb">
							<img src="assets/images/slider/banner4.jpg" height="250" alt="africneibor">
							<div class="service-icon">
								<img src="assets/images/service/service-icon3.png" alt="africneibor">
							</div>
						</div>
						<div class="service-content">
							<h4><a href="services"> Maintenance Requests</a></h4>
							<p>Handle maintenance requests efficiently, ensuring your properties are always in top condition and tenants are satisfied.</p>
						</div>
						<div class="Lifesafe-btn service">
							<a href="#">Read More +</a>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 mt-5">
					<div class="service-single-box wow fadeInUp" data-wow-delay="0.4s" data-wow-duration="1s">
						<div class="service-thumb">
							<img src="assets/images/about/im3.jpg" height="250" alt="africneibor">
							<div class="service-icon">
								<img src="assets/images/service/service-icon1.png" alt="africneibor">
							</div>
						</div>
						<div class="service-content">
							<h4><a href="services"> Secured Document Storage</a></h4>
							<p>Safeguard your property-related documents and contracts securely within the app, eliminating the need for physical paperwork.</p>
						</div>
						<div class="Lifesafe-btn service">
							<a href="services">Read More +</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-6 mt-5">
					<div class="service-single-box wow fadeInUp" data-wow-delay="0.4s" data-wow-duration="1s">
						<div class="service-thumb">
							<img src="assets/images/about/aboutbg.jpg" height="250" alt="africneibor">
							<div class="service-icon">
								<img src="assets/images/service/service-icon1.png" alt="africneibor">
							</div>
						</div>
						<div class="service-content">
							<h4><a href="services"> Facial Recognition</a></h4>
							<p>Utilize facial recognition technology to register tenants, hotel lodgers, and restaurant customers, enhancing security and reducing criminal activity.</p>
						</div>
						<div class="Lifesafe-btn service">
							<a href="services">Read More +</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-6 mt-5">
					<div class="service-single-box wow fadeInUp" data-wow-delay="0.4s" data-wow-duration="1s">
						<div class="service-thumb">
							<img src="assets/images/slider/banner3.jpeg" height="250" alt="africneibor">
							<div class="service-icon">
								<img src="assets/images/service/service-icon1.png" alt="africneibor">
							</div>
						</div>
						<div class="service-content">
							<h4><a href="services"> Seamless Communication</a></h4>
							<p>Communicate with tenants, staff, and service providers through the app, promoting quick issue resolution and efficient management.</p>
						</div>
						<div class="Lifesafe-btn service">
							<a href="services">Read More +</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--==================================================-->
	<!-- End Service Area -->
	<!--==================================================-->

	<!--==================================================-->
	<!-- Start Protection Area -->
	<!--==================================================-->
	<div class="protection-area">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-lg-4"></div>
				<div class="col-lg-6 col-md-12">
					<div class="protection-content">
						<h4>Ready to experience the future of property management?</h4>
					</div>
				</div>
				<div class="col-lg-2 col-md-12">
					<div class="Lifesafe-btn protection">
						<a href="contact">Contact Now</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--==================================================-->
	<!-- End Protection Area -->
	<!--==================================================-->



	<!--==================================================-->
	<!-- Start Testimonial Area -->
	<!--==================================================-->
	<div class="testimonial-area">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-lg-6 col-md-12">
					<div class="section-title wow fadeInUp" data-wow-delay="0.2s" data-wow-duration="1s">
						<div class="section-sub-title">
							<h4>Our Testimonials</h4>
						</div>
						<div class="section-main-title">
							<h2>What People Say About
								Our Company.</h2>
						</div>
					</div>
				</div>
				<div class="col-lg-6 col-md-12">
					<div class="testimonial-discription wow fadeInUp" data-wow-delay="0.3s" data-wow-duration="1s">
						<p>Join thousands of satisfied landlords and property owners who have experienced the AfricNeibor difference. Say goodbye to outdated spreadsheets and paperwork and hello to a digital revolution in property management. </p>
					</div>
				</div>
			</div>
			<div class="row align-items-center">
				<div class="col-lg-6 col-md-12">
					<div class="row">
						<div class="col-lg-12">
							<div class="testi-single-box wow fadeInUp" data-wow-delay="0.2s" data-wow-duration="1s">
								<div class="testi-title">
									<h4>SB Shinur Islam</h4>
									<span>CEO Transport Ltd.</span>
								</div>
								<div class="testi-icon">
									<i class="bi bi-star-fill"></i>
									<i class="bi bi-star-fill"></i>
									<i class="bi bi-star-fill"></i>
									<i class="bi bi-star-fill"></i>
									<i class="bi bi-star-fill"></i>
								</div>
								<div class="testi-discription">
									<p>The best property management company indeed </p>
								</div>
								<div class="testi-qouet">
									<i class="bi bi-quote"></i>
								</div>
							</div>
						</div>
						<div class="col-lg-12">
							<div class="testi-single-box wow fadeInUp" data-wow-delay="0.4s" data-wow-duration="1s">
								<div class="testi-title">
									<h4>John obi</h4>
									<span>Land owner.</span>
								</div>
								<div class="testi-icon">
									<i class="bi bi-star-fill"></i>
									<i class="bi bi-star-fill"></i>
									<i class="bi bi-star-fill"></i>
									<i class="bi bi-star-fill"></i>
									<i class="bi bi-star-fill"></i>
								</div>
								<div class="testi-discription">
									<p>I dont have to worry about the security of my properties anymore. Africneibor is really the best </p>
								</div>
								<div class="testi-qouet">
									<i class="bi bi-quote"></i>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-6 col-md-12">
					<div class="testi-thumb wow fadeInUp" data-wow-delay="0.6s" data-wow-duration="1s">
						<img src="assets/images/testimonial/testi-thumb.png" alt="africneibor">
						<div class="testi-counter">
							<h4 class="counter">500</h4>
							<span>+</span>
							<p>Happy Customers</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--==================================================-->
	<!-- End Testimonial Area -->
	<!--==================================================-->


	

	<?php
		include("footer.php")
	?>