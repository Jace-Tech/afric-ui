<?php
$title = "Ask us Anything About AfricNeibor";
$desc="Have any questions about us and our services? We answered many questions about AfricNeibor. check our FAQ here ";
 include("header.php"); ?>

	<!--==================================================-->
	<!-- Start Breatcome Area -->
	<!--==================================================-->
	<div class="breatcome-area breatcome-area-faq">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12">
					<div class="breatcome-content">
						<div class="breatcome-title">
							<h1>Faq</h1>
						</div>
						<div class="bratcome-text">
							<ul>
								<li><a href="index.html">Home</a></li>
								<li>Faq</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--==================================================-->
	<!-- End Breatcome Area -->
	<!--==================================================-->

	<!--==================================================-->
	<!-- Start Team Area -->
	<!--==================================================-->
	<div class="faq-area wow fadeInUp" data-wow-delay="0.3s" data-wow-duration="1s">
		<div class="container">
			<div class="row p-90">
				<div class="col-lg-12">
					<div class="tab_container">
						<div id="tab1" class="tab_content">
							<ul class="accordion">
								<li>
									<a class="active inner"><span> 1. What is Africneibor? </span> <i
											class="bi bi-chevron-double-right"></i></a>
									<p style="display: block;"> Africneibor is your premier solution for streamlined rental property management in Nigeria. Managing rental properties has historically been a complex and challenging task, but with AfricNeibor, we offer a comprehensive suite of services and a user-friendly website to simplify the entire process.</p>
								</li>
								<li>
									<a class="inner"><span> 2. Is Africneibor secure? </span> <i
											class="bi bi-chevron-double-right"></i></a>
									<p>We understand the importance of safeguarding your property and tenant data. That's why we prioritize data security, employing robust measures to protect your information and provide you with peace of mind. Africneibor is 100% secure</p>
								</li>
								<li>
									<a class="inner"><span> 3. Why should i choose Africneibor to manage my properties? </span> <i
											class="bi bi-chevron-double-right"></i></a>
									<p>At AfricNeibor, our mission is to empower property owners to take control of their rental properties, enhance tenant satisfaction, and maximize profitability through cutting-edge technology and unparalleled service.</p><br>
									<p>We leverage the latest advancements in technology to deliver a seamless and efficient property management experience. Our user-friendly mobile app puts the power of property management in the palm of your hand.</p><br>
									<p> From tenant screening and lease management to maintenance requests and secure document storage, AfricNeibor offers a comprehensive suite of services to meet all your property management needs.</p>
								</li>
								<li>
									<a class="inner"><span> 4. Is Africneibor free or offering a paid services? </span> <i
											class="bi bi-chevron-double-right"></i></a>
									<p>Africneibor collects a little subscription fee from all Landlords/Property owners and employed tenants every month to give you the best services. However Africneibor is free for students and unemployed users, everyone can experience the seamless services of africneibor no matter your status</p>
								</li>

								<li>
									<a class="inner"><span> 5. How fast is Africneibor customer service? </span> <i
											class="bi bi-chevron-double-right"></i></a>
									<p>Our dedicated team is committed to providing exceptional customer service every step of the way. Whether you have a question about our services or need assistance with a maintenance request, we're here to help.</p>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--==================================================-->
	<!-- End Team Us Area -->
	<!--==================================================-->
<?php
		include("footer.php")
	?>