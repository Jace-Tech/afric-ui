<?php
$title = "Experience the ease and efficiency of AfricNeibor - Contact Us";
$desc="Ready to experience the future of property management? Contact us today to learn more about our services or to schedule a demo of our user-friendly mobile app.";
 include("header.php"); ?>

	<!--==================================================-->
	<!-- Start Breatcome Area -->
	<!--==================================================-->
	<div class="breatcome-area breatcome-area-contact">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12">
					<div class="breatcome-content">
						<div class="breatcome-title">
							<h1>Contact</h1>
						</div>
						<div class="bratcome-text">
							<ul>
								<li><a href="index">Home</a></li>
								<li>Contact</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--==================================================-->
	<!-- End Breatcome Area -->
	<!--==================================================-->

	<!--==================================================-->
	<!-- Start Contact Area -->
	<!--==================================================-->
	<div class="contact-area wow fadeInUp" data-wow-delay="0.3s" data-wow-duration="1s">
		<div class="container">
			<div class="row contact">
				<div class="col-lg-4 col-md-12">
					<div class="contact-single-box">
						<div class="contact-title">
							<h4>Contact Informatlon</h4>
						</div>
						<div class="contact-items">
							<div class="contact-icon">
								<i class="bi bi-geo-alt-fill"></i>
							</div>
							<div class="contact-content">
								<h4>Address</h4>
								<h6>Lagos, Nigeria</h6>
							</div>
						</div>
						<div class="contact-items">
							<div class="contact-icon">
								<i class="bi bi-phone-fill"></i>
							</div>
							<div class="contact-content">
								<h4>Contact Namber</h4>
								<h6>(+6656) 1598596969</h6>
							</div>
						</div>
						<div class="contact-items">
							<div class="contact-icon">
								<i class="bi bi-envelope-fill"></i>
							</div>
							<div class="contact-content">
								<h4>Email Us</h4>
								<h6>info@africneibor.com</h6>
							</div>
						</div>
					</div>
				</div>
				<div class="col-lg-8 col-md-12">
					<div class="contact-box">
						<div class="contact-box-title">
							<h4>Get A Quote</h4>
						</div>
						<form action="" method="POST" id="it-form">
							<div class="row">
								<div class="col-lg-6 col-md-6">
									<div class="form-box">
										<input type="text" name="name" placeholder="Your Name">
									</div>
								</div>
								<div class="col-lg-6 col-md-6">
									<div class="form-box">
										<input type="text" name="email" placeholder="Email Address">
									</div>
								</div>
								<div class="col-lg-6 col-md-6">
									<div class="form-box">
										<input type="text" name="phone" placeholder="Phone Numbar">
									</div>
								</div>
								<div class="col-lg-6 col-md-6">
									<div class="form-box">
										<input type="text" name="website" placeholder="Website">
									</div>
								</div>
								<div class="col-lg-12">
									<div class="form-box">
										<input type="text" name="name" placeholder="Your Company Name">
									</div>
								</div>
								<div class="col-lg-12 col-md-12">
									<div class="form-box">
										<textarea name="massage" id="massage" cols="30" rows="10"
											placeholder="Write your question here"></textarea>
									</div>
								</div>
								<div class="col-lg-12 col-md-12">
									<div class="form-box-button">
										<button type="Submit"> Get a quote</button>
									</div>
								</div>
							</div>
						</form>
						<div id="status"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--==================================================-->
	<!-- End Contact Area -->
	<!--==================================================-->

	<!--==================================================-->
	<!-- Start map Area -->
	<!--==================================================-->

	<div class="map-area wow fadeInUp" data-wow-delay="0.6s" data-wow-duration="1s">
		<div class="container-fluid p-0">
			<div class="row">
				<div class="col-lg-12 col-md-12">
					<!-- <iframe
						src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7496149.95373021!2d85.84621250756469!3d23.452185887261447!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30adaaed80e18ba7%3A0xf2d28e0c4e1fc6b!2sBangladesh!5e0!3m2!1sen!2sbd!4v1635150422284!5m2!1sen!2sbd"
						width="1920" height="608" style="border:0;" allowfullscreen="" loading="lazy"></iframe> -->
				</div>
			</div>
		</div>
	</div>

	<!--==================================================-->
	<!-- End map Area -->
	<!--==================================================-->

	<?php
		include("footer.php")
	?>