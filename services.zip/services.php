<?php
$title = "AFRICNEIBOR - We offer the best services to enhance property maintenance";
$desc=" Your premier solution for streamlined rental property management in Nigeria. Managing rental properties has historically been a complex and challenging task, but with AfricNeibor, we offer a comprehensive suite of services and a user-friendly website to simplify the entire process.";
 include("header.php"); ?>

	<!--==================================================-->
	<!-- Start Breatcome Area -->
	<!--==================================================-->
	<div class="breatcome-area breatcome-area-service">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12">
					<div class="breatcome-content">
						<div class="breatcome-title">
							<h1>Our Services</h1>
						</div>
						<div class="bratcome-text">
							<ul>
								<li><a href="index">Home</a></li>
								<li>Service</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--==================================================-->
	<!-- End Breatcome Area -->
	<!--==================================================-->

	<!--==================================================-->
	<!-- Start Service Area -->
	<!--==================================================-->
	<!--==================================================-->
	<div class="service-area inner-page">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="section-title text-center wow fadeInUp" data-wow-delay="0.2s" data-wow-duration="1s">
						<div class="section-sub-title">
							<h4>Our Services</h4>
						</div>
						
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-4 col-md-6">
					<div class="service-single-box wow fadeInUp" data-wow-delay="0.4s" data-wow-duration="1s">
						<div class="service-thumb">
							<img src="assets/images/slider/im.png" height="250" alt="africneibor">
							<div class="service-icon">
								<img src="assets/images/service/service-icon1.png" alt="africneibor">
							</div>
						</div>
						<div class="service-content">
							<h4><a href="services"> Tenant Management</a></h4>
							<p>Provide thorough background checks on all tenants, hotels, and restaurant customers, ensuring a safe and secure environment.</p>
						</div>
						
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="service-single-box wow fadeInUp" data-wow-delay="0.6s" data-wow-duration="1s">
						<div class="service-thumb">
							<img src="assets/images/about/im2.jpg" height="250" alt="africneibor">
							<div class="service-icon">
								<img src="assets/images/service/service-icon2.png" alt="africneibor">
							</div>
						</div>
						<div class="service-content">
							<h4><a href="services"> Lease Management</a></h4>
							<p>Keep track of lease agreements, renewals, and rent payments effortlessly, ensuring timely payments and compliance</p>
						</div>
						
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="service-single-box wow fadeInUp" data-wow-delay="0.8s" data-wow-duration="1s">
						<div class="service-thumb">
							<img src="assets/images/slider/banner4.jpg" height="250" alt="africneibor">
							<div class="service-icon">
								<img src="assets/images/service/service-icon3.png" alt="africneibor">
							</div>
						</div>
						<div class="service-content">
							<h4><a href="services"> Maintenance Requests</a></h4>
							<p>Handle maintenance requests efficiently, ensuring your properties are always in top condition and tenants are satisfied.</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="service-single-box wow fadeInUp" data-wow-delay="0.4s" data-wow-duration="1s">
						<div class="service-thumb">
							<img src="assets/images/about/im3.jpg" height="250" alt="africneibor">
							<div class="service-icon">
								<img src="assets/images/service/service-icon1.png" alt="africneibor">
							</div>
						</div>
						<div class="service-content">
							<h4><a href="services"> Secured Document Storage</a></h4>
							<p>Safeguard your property-related documents and contracts securely within the app, eliminating the need for physical paperwork.</p>
						</div>
						
					</div>
				</div>

				<div class="col-lg-4 col-md-6">
					<div class="service-single-box wow fadeInUp" data-wow-delay="0.4s" data-wow-duration="1s">
						<div class="service-thumb">
							<img src="assets/images/about/aboutbg.jpg" height="250" alt="africneibor">
							<div class="service-icon">
								<img src="assets/images/service/service-icon1.png" alt="africneibor">
							</div>
						</div>
						<div class="service-content">
							<h4><a href="services"> Facial Recognition</a></h4>
							<p>Utilize facial recognition technology to register tenants, hotel lodgers, and restaurant customers, enhancing security and reducing criminal activity.</p>
						</div>
						
					</div>
				</div>

				<div class="col-lg-4 col-md-6">
					<div class="service-single-box wow fadeInUp" data-wow-delay="0.4s" data-wow-duration="1s">
						<div class="service-thumb">
							<img src="assets/images/slider/banner3.jpeg" height="250" alt="africneibor">
							<div class="service-icon">
								<img src="assets/images/service/service-icon1.png" alt="africneibor">
							</div>
						</div>
						<div class="service-content">
							<h4><a href="services"> Seamless Communication</a></h4>
							<p>Communicate with tenants, staff, and service providers through the app, promoting quick issue resolution and efficient management.</p>
						</div>
						
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--==================================================-->
	<!-- End Service Area -->
	<!--==================================================-->

	<!--==================================================-->
	<!-- Start Protection Area -->
	<!--==================================================-->
	<div class="protection-area">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-lg-4"></div>
				<div class="col-lg-6 col-md-6">
					<div class="protection-content">
						<h4>Ready to experience the future of property management?</h4>
					</div>
				</div>
				<div class="col-lg-2 col-md-6">
					<div class="Lifesafe-btn protection">
						<a href="#">Contact Now</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--==================================================-->
	<!-- End Protection Area -->
	<!--==================================================-->

	<!--==================================================-->
	<!-- Start Feature Area -->
	<!--==================================================-->
	<div class="feature-area inner-page">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-6">
					<div class="feature-single-box wow fadeInUp" data-wow-delay="0.2s" data-wow-duration="1s">
						<div class="fetaure-icon">
							<img src="assets/images/service/feature-icon1.png" alt="">
						</div>
						<div class="feature-content">
							<h4>Trusted Company</h4>
							<p>your trusted partner in modernizing property management across Nigeria</p>
						</div>
						<div class="feature-shape">
							<img src="assets/images/service/feature-one-shape-1.png" alt="">
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-6">
					<div class="feature-single-box wow fadeInUp" data-wow-delay="0.4s" data-wow-duration="1s">
						<div class="fetaure-icon">
							<img src="assets/images/service/feature-icon4.png" alt="africneibor">
						</div>
						<div class="feature-content">
							<h4>Innovative Technology</h4>
							<p>We leverage the latest advancements in technology to manage your properties.</p>
						</div>
						<div class="feature-shape">
							<img src="assets/images/service/feature-one-shape-1.png" alt="africneibor">
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-6">
					<div class="feature-single-box wow fadeInUp" data-wow-delay="0.6s" data-wow-duration="1s">
						<div class="fetaure-icon">
							<img src="assets/images/service/feature-icon3.png" alt="africneibor">
						</div>
						<div class="feature-content">
							<h4>Focus on Security</h4>
							<p>We understand the importance of safeguarding your property and tenant data.</p>
						</div>
						<div class="feature-shape">
							<img src="assets/images/service/feature-one-shape-1.png" alt="africneibor">
						</div>
					</div>
				</div>
				<div class="col-lg-3 col-md-6">
					<div class="feature-single-box wow fadeInUp" data-wow-delay="0.8s" data-wow-duration="1s">
						<div class="fetaure-icon">
							<img src="assets/images/service/feature-icon4.png" alt="africneibor">
						</div>
						<div class="feature-content">
							<h4>24/7 Fast Support</h4>
							<p>Our dedicated team is committed to providing exceptional customer support every step of the way.</p>
						</div>
						<div class="feature-shape">
							<img src="assets/images/service/feature-one-shape-1.png" alt="">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--==================================================-->
	<!-- End Feature Area -->
	<!--==================================================-->
<?php
		include("footer.php")
	?>