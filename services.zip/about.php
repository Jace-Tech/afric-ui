<?php
$title = "ABOUT AFRICNEIBOR - A safe Home for All Property Owners";
$desc=" At AfricNeibor, we specialize in enhancing property maintenance, tenant tracking, and simplifying property ownership for landlords and property owners across Nigeria.";
 include("header.php"); ?>

	<!--==================================================-->
	<!-- Start Breatcome Area -->
	<!--==================================================-->
	<div class="breatcome-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12">
					<div class="breatcome-content">
						<div class="breatcome-title">
							<h1>About Us</h1>
						</div>
						<div class="bratcome-text">
							<ul>
								<li><a href="index">Home</a></li>
								<li>About Us</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--==================================================-->
	<!-- End Breatcome Area -->
	<!--==================================================-->

	<!--==================================================-->
	<!-- Start About Area -->
	<!--==================================================-->
	<div class="about-area inner-page">
		<div class="container">
			<div class="row">
				<div class="col-lg-5 col-md-12">
					<div class="about-thumb wow fadeInRight" data-wow-delay="0.3s" data-wow-duration="1s">
						<img src="assets/images/about/im1.jpg" alt="">
					</div>
				</div>
				<div class="col-lg-7 col-md-12">
					<div class="section-title wow fadeInUp" data-wow-delay="0.2s" data-wow-duration="1s">
						<div class="section-sub-title">
							<h4>About Our Company</h4>
						</div>
						<div class="section-main-title about">
							<h2>Your Trusted Partner in Property Management</h2>
						</div>
					</div>
					<div class="about-discription wow fadeInUp" data-wow-delay="0.4s" data-wow-duration="1s">
						<p>Your trusted partner in modernizing property management across Nigeria. Founded with a vision to simplify the complexities of managing rental properties, AfricNeibor offers innovative solutions tailored to the needs of landlords, property owners, and tenants alike. </p>
					</div>
					<div class="row">
						<div class="col-lg-12">
							<div class="tab list-tab">
								<ul class="tabs active wow fadeInUp" data-wow-delay="0.2s" data-wow-duration="1s">
									<li class="current"><a href="#">Our Mission</a></li>
									<li><a href="#">Our Vision</a></li>
									<li><a href="#">Why choose us</a></li>
								</ul>
								<div class="tab_content">
									<div class="tabs_item">
										<div class="row">
											<div class="col-lg-4 col-md-12 col-sm-6">
												<div class="about-thumb wow fadeInRight" data-wow-delay="0.2s"
													data-wow-duration="1s">
													<img src="assets/images/about/im2.jpg" alt="">
												</div>
											</div>
											<div class="col-lg-8 col-md-12 col-sm-6">
												<div class="about-list wow fadeInUp" data-wow-delay="0.4s"
													data-wow-duration="1s">
													<ul>
														<li><i class="bi bi-chevron-double-right"></i> Empower property owners to take control of their rental properties</li>
														<li><i class="bi bi-chevron-double-right"></i> enhance tenant satisfaction
														</li>
														<li><i class="bi bi-chevron-double-right"></i> maximize profitability through cutting-edge technology and unparalleled service
														</li>
													</ul>
												</div>
											</div>
										</div>
									</div>
									<div class="tabs_item" style="display: none;">
										<div class="row">
											<div class="col-lg-4 col-md-12 col-sm-6">
												<div class="about-thumb wow fadeInRight" data-wow-delay="0.2s"
													data-wow-duration="1s">
													<img src="assets/images/about/im4.jpg" alt="">
												</div>
											</div>
											<div class="col-lg-8 col-md-12 col-sm-6">
												<div class="about-list wow fadeInUp" data-wow-delay="0.4s"
													data-wow-duration="1s">
													<ul>
														<li><i class="bi bi-chevron-double-right"></i> To simplify the complexities of managing rental properties </li>
														<li><i class="bi bi-chevron-double-right"></i> To offer innovative solutions tailored to the needs of landlords, property owners, and tenants alike.
														</li>
														<li><i class="bi bi-chevron-double-right"></i> To be the best property management company
														</li>
													</ul>
												</div>
											</div>
											
										</div>
									</div>
									<div class="tabs_item" style="display: none;">
										<div class="row">
											<div class="col-lg-4 col-md-12 col-sm-6">
												<div class="about-thumb wow fadeInRight" data-wow-delay="0.2s"
													data-wow-duration="1s">
													<img src="assets/images/about/im3.jpg" alt="">
												</div>
											</div>
											<div class="col-lg-8 col-md-12 col-sm-6">
												<div class="about-list wow fadeInUp" data-wow-delay="0.4s"
													data-wow-duration="1s">
													<ul>
														<li><i class="bi bi-chevron-double-right"></i> We understand the importance of safeguarding your property </li>
														<li><i class="bi bi-chevron-double-right"></i> We provide exceptional customer service
														</li>
														<li><i class="bi bi-chevron-double-right"></i> We leverage technology to manage your properties
														</li>
													</ul>
												</div>
											</div>
											
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--==================================================-->
	<!-- End About Area -->
	<!--==================================================-->


	<!--==================================================-->
	<!-- Start Service Area -->
	<!--==================================================-->
	<!--==================================================-->
	<div class="service-area inner-page">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="section-title text-center wow fadeInUp" data-wow-delay="0.2s" data-wow-duration="1s">
						<div class="section-sub-title">
							<h4>Our Services</h4>
						</div>
						
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-4 col-md-6 mt-5">
					<div class="service-single-box wow fadeInUp" data-wow-delay="0.4s" data-wow-duration="1s">
						<div class="service-thumb">
							<img src="assets/images/slider/im.png" height="250" alt="africneibor">
							<div class="service-icon">
								<img src="assets/images/service/service-icon1.png" alt="africneibor">
							</div>
						</div>
						<div class="service-content">
							<h4><a href="services"> Tenant Management</a></h4>
							<p>Provide thorough background checks on all tenants, hotels, and restaurant customers, ensuring a safe and secure environment.</p>
						</div>
						<div class="Lifesafe-btn service">
							<a href="services">Read More +</a>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 mt-5">
					<div class="service-single-box wow fadeInUp" data-wow-delay="0.6s" data-wow-duration="1s">
						<div class="service-thumb">
							<img src="assets/images/about/im2.jpg" height="250" alt="africneibor">
							<div class="service-icon">
								<img src="assets/images/service/service-icon2.png" alt="africneibor">
							</div>
						</div>
						<div class="service-content">
							<h4><a href="services"> Lease Management</a></h4>
							<p>Keep track of lease agreements, renewals, and rent payments effortlessly, ensuring timely payments and compliance</p>
						</div>
						<div class="Lifesafe-btn service">
							<a href="services">Read More +</a>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 mt-5">
					<div class="service-single-box wow fadeInUp" data-wow-delay="0.8s" data-wow-duration="1s">
						<div class="service-thumb">
							<img src="assets/images/slider/banner4.jpg" height="250" alt="africneibor">
							<div class="service-icon">
								<img src="assets/images/service/service-icon3.png" alt="africneibor">
							</div>
						</div>
						<div class="service-content">
							<h4><a href="services"> Maintenance Requests</a></h4>
							<p>Handle maintenance requests efficiently, ensuring your properties are always in top condition and tenants are satisfied.</p>
						</div>
						<div class="Lifesafe-btn service">
							<a href="services">Read More +</a>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 mt-5">
					<div class="service-single-box wow fadeInUp" data-wow-delay="0.4s" data-wow-duration="1s">
						<div class="service-thumb">
							<img src="assets/images/about/im3.jpg" height="250" alt="africneibor">
							<div class="service-icon">
								<img src="assets/images/service/service-icon1.png" alt="africneibor">
							</div>
						</div>
						<div class="service-content">
							<h4><a href="services"> Secured Document Storage</a></h4>
							<p>Safeguard your property-related documents and contracts securely within the app, eliminating the need for physical paperwork.</p>
						</div>
						<div class="Lifesafe-btn service">
							<a href="services">Read More +</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-6 mt-5">
					<div class="service-single-box wow fadeInUp" data-wow-delay="0.4s" data-wow-duration="1s">
						<div class="service-thumb">
							<img src="assets/images/about/aboutbg.jpg" height="250" alt="africneibor">
							<div class="service-icon">
								<img src="assets/images/service/service-icon1.png" alt="africneibor">
							</div>
						</div>
						<div class="service-content">
							<h4><a href="services"> Facial Recognition</a></h4>
							<p>Utilize facial recognition technology to register tenants, hotel lodgers, and restaurant customers, enhancing security and reducing criminal activity.</p>
						</div>
						<div class="Lifesafe-btn service">
							<a href="services">Read More +</a>
						</div>
					</div>
				</div>

				<div class="col-lg-4 col-md-6 mt-5">
					<div class="service-single-box wow fadeInUp" data-wow-delay="0.4s" data-wow-duration="1s">
						<div class="service-thumb">
							<img src="assets/images/slider/banner3.jpeg" height="250" alt="africneibor">
							<div class="service-icon">
								<img src="assets/images/service/service-icon1.png" alt="africneibor">
							</div>
						</div>
						<div class="service-content">
							<h4><a href="services"> Seamless Communication</a></h4>
							<p>Communicate with tenants, staff, and service providers through the app, promoting quick issue resolution and efficient management.</p>
						</div>
						<div class="Lifesafe-btn service">
							<a href="services">Read More +</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--==================================================-->
	<!-- End Service Area -->
	<!--==================================================-->

	<!--==================================================-->
	<!-- Start Protection Area -->
	<!--==================================================-->
	<div class="protection-area">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-lg-4"></div>
				<div class="col-lg-6 col-md-6">
					<div class="protection-content">
						<h4>Ready to experience the future of property management?</h4>
					</div>
				</div>
				<div class="col-lg-2 col-md-6">
					<div class="Lifesafe-btn protection">
						<a href="contact">Contact Now</a>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--==================================================-->
	<!-- End Protection Area -->
	<!--==================================================-->

	<!--==================================================-->
	<!-- Start Choose Us Area -->
	<!--==================================================-->
	<div class="choose-us-area">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-lg-6 col-md-12">
					<div class="section-title wow fadeInUp" data-wow-delay="0.2s" data-wow-duration="1s">
						<div class="section-sub-title">
							<h4>Why Choose Us</h4>
						</div>
						<div class="section-main-title">
							<h2>What sets our
								Property Management Services Apart.</h2>
						</div>
						
					</div>
					<div class="row choose">
						<div class="col-lg-6 col-md-12">
							<div class="choose-list wow fadeInUp" data-wow-delay="0.4s" data-wow-duration="1s">
								<span><i class="bi bi-chevron-double-right"></i> We leverage the latest advancements in technology to deliver a seamless and efficient property management experience. Our user-friendly mobile app puts the power of property management in the palm of your hand.</span>
								<span><i class="bi bi-chevron-double-right"></i> We understand the importance of safeguarding your property and tenant data. That's why we prioritize data security, employing robust measures to protect your information and provide you with peace of mind.</span>
							</div>
						</div>
						<div class="col-lg-6 col-md-12">
							<div class="choose-list wow fadeInUp" data-wow-delay="0.6s" data-wow-duration="1s">
								<span><i class="bi bi-chevron-double-right"></i> From tenant screening and lease management to maintenance requests and secure document storage, AfricNeibor offers a comprehensive suite of services to meet all your property management needs.</span>
								<span><i class="bi bi-chevron-double-right"></i> Our dedicated team is committed to providing exceptional customer service every step of the way. Whether you have a question about our services or need assistance with a maintenance request, we're here to help.</span>
							</div>
						</div>
					</div>
					<div class="Lifesafe-btn choose wow fadeInUp" data-wow-delay="0.8s" data-wow-duration="1s">
						<a href="account/signup-email">Register with us now</a>
					</div>
				</div>
				<div class="col-lg-6 col-md-12">
					<div class="choose-thumb-items">
						<div class="choose-thumb wow fadeInLeft" data-wow-delay="0.4s" data-wow-duration="1s">
							<img src="assets/images/resource/choose1.png" alt="">
						</div>
						<div class="choose-thumb wow fadeInUp" data-wow-delay="0.4s" data-wow-duration="1s">
							<img src="assets/images/resource/choose2.png" alt="">
						</div>
						<div class="choose-thumb three">
							<img src="assets/images/resource/choose3.png" alt="">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--==================================================-->
	<!-- End Choose Us Area -->
	<!--==================================================-->

	<?php
		include("footer.php")
	?>