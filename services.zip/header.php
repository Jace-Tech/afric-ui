<!DOCTYPE HTML>
<html lang="en-US">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<title><?php echo $title;?></title>

	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="<?php echo $desc;?>">
	 <meta  name="keywords" content="AfricNeibor, africneibor, property management, lease management, tenant management, property ownership, data collection, landlords, tenants">
	 <meta name="author" content="AfricNeibor">

	<!-- Favicon -->
	<link rel="icon" type="image/png" sizes="56x56" href="logo.png">
	<!-- bootstrap CSS -->
	<link rel="stylesheet" href="assets/css/bootstrap.min.css" type="text/css" media="all">
	<!-- carousel CSS -->
	<link rel="stylesheet" href="assets/css/owl.carousel.min.css" type="text/css" media="all">
	<!-- animate CSS -->
	<link rel="stylesheet" href="assets/css/animate.css" type="text/css" media="all">
	<!-- font-awesome CSS -->
	<link rel="stylesheet" href="assets/css/all.min.css" type="text/css" media="all">
	<!-- font-flaticon CSS -->
	<link rel="stylesheet" href="assets/css/flaticon.css" type="text/css" media="all">
	<!-- theme-default CSS -->
	<link rel="stylesheet" href="assets/css/theme-default.css" type="text/css" media="all">
	<!-- meanmenu CSS -->
	<link rel="stylesheet" href="assets/css/meanmenu.min.css" type="text/css" media="all">
	<!-- transitions CSS -->
	<link rel="stylesheet" href="assets/css/owl.transitions.css" type="text/css" media="all">
	<!-- venobox CSS -->
	<link rel="stylesheet" href="venobox/venobox.css" type="text/css" media="all">
	<!-- bootstrap icons -->
	<link rel="stylesheet" href="assets/css/bootstrap-icons.css" type="text/css" media="all">
	<!-- Slick Slider -->
	<link rel="stylesheet" type="text/css" href="assets/slick/slick.css">
	<link rel="stylesheet" type="text/css" href="assets/slick/slick-theme.css">
	<!-- Main Style CSS -->
	<link rel="stylesheet" href="assets/css/style.css" type="text/css" media="all">
	<!-- Dropdown CSS -->
	<link rel="stylesheet" href="assets/css/dropdown.css" type="text/css" media="all">
	<!-- responsive CSS -->
	<link rel="stylesheet" href="assets/css/responsive.css" type="text/css" media="all">
	<!-- modernizr js -->
	<script src="assets/js/vendor/modernizr-3.5.0.min.js"></script>
</head>

<body>
	<!-- loder -->
	<div class="loader-wrapper">
		<div class="loader-wrap">
			<div class="preloader">
				<div id="shifa-preloader" class="shifa-preloader">
					<div class="layer layer-one"><span class="overlay"></span></div>
					<div class="animation-preloader">
						<div class="spinner"><!-- <img src="logo.png"> --></div>
						<div class="txt-loading">
							<span data-text-preloader="A" class="letters-loading">
								A
							</span>
							<span data-text-preloader="F" class="letters-loading">
								F
							</span>
							<span data-text-preloader="R" class="letters-loading">
								R
							</span>
							<span data-text-preloader="I" class="letters-loading">
								I
							</span>
							<span data-text-preloader="C" class="letters-loading">
								C
							</span>
							<span data-text-preloader="N" class="letters-loading">
								N
							</span>
							<span data-text-preloader="E" class="letters-loading">
								E
							</span>
							<span data-text-preloader="I" class="letters-loading">
								I
							</span>
							<span data-text-preloader="B" class="letters-loading">
								B
							</span>
							<span data-text-preloader="O" class="letters-loading">
								O
							</span>
							<span data-text-preloader="R" class="letters-loading">
								R
							</span>
						</div>
					</div>  
				</div>
			</div>
		</div>
		<div class="loader"></div>
		<div class="loder-section left-section"></div>
		<div class="loder-section right-section"></div>
	</div>

	<!--==================================================-->
	<!-- Start Header Area -->
	<!--==================================================-->
	<header class="header-area" id="sticky-header">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-lg-2">
					<div class="logo">
						<a href="index"><img src="logo.png" alt="africneibor logo" width="100" height="80"></a>
					</div>
				</div>
				<div class="col-lg-10">
					<div class="header-menu">
						<ul>
							<li><a href="index">Home</a></li>
							<li><a href="about">About Us</a></li>
							<li><a href="services">Services </a>
							</li>
							<li><a href="services">FAQ </a></li>
							
							
							<li><a href="contact">Contact Us</a></li>
						</ul>
						<div class="header-right">
							<div class="Lifesafe-btn">
								<a href="account/signup-email">Register</a>
							</div>
							
							<div class="Lifesafe-btn" style="margin-left: 4%;">
								<a href="account/login">Login</a>
							</div>
							<div class="header-sidebar">
								<a class="navSidebar-button" href="#"><i class="bi bi-grid-3x3-gap-fill"></i></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>

	<!-- Lifesafe Mobile Menu Area -->
	<div class="mobile-menu-area sticky-menu" id="navbar">
		<div class="mobile-menu">
			<div class="mobile-logo">
				<a href="index"><img src="logo.png" alt="africneibor logo" width="100" height="90"></a>
			</div>
			<div class="side-menu-info">
				<div class="sidebar-menu">
					<a class="navSidebar-button" href="#"><i class="bi bi-justify-right"></i></a>
				</div>
			</div>
		</div>
	</div>
	<!--==================================================-->
	<!-- End Header Area -->
	<!--==================================================-->